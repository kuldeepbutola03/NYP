Cufon.replace('#menu a, h2, .button1, h3, #ContactForm a', { fontFamily: 'Amaranth', hover:true });

